from django.conf.urls import url
from django.conf.urls import include
from django.urls import path
from maps_app import views
# from . import views
import json

urlpatterns = [


]
